This data was derived from the datasets available at 
http://www.grouplens.org/node/73

It is meant to be used only for the CS246 Assignment. For all other uses, please abide by the terms of use at the above website.
